# TopMinded AI Manager — starter project

This is the first source-code prototype, not a finished production APK.

## What is included
- Android app dashboard (Kotlin + Jetpack Compose)
- Settings for the planned publishing cadence: 2 Shorts/day and 2 long videos/week
- FastAPI backend starter with health/status endpoints and a scheduler hook
- Clear configuration points for AI script generation, American-English TTS, video rendering, and YouTube OAuth upload

## Important
The app cannot publish autonomously until you connect credentials and deploy the backend:
1. A Google Cloud project with YouTube Data API v3 enabled and OAuth consent configured.
2. YouTube channel authorization (OAuth; never send your password).
3. An AI provider API key and a TTS provider/API key.
4. A video-rendering worker and persistent server hosting.
5. A server URL configured in the Android app.

The starter deliberately does not contain API keys or pretend these integrations are already connected. YouTube may impose API quota and upload restrictions. Keep human review enabled during testing, then enable unattended publishing only after you verify output quality and channel permissions.

## Run backend locally
```bash
cd backend
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn main:app --reload
```
Open http://127.0.0.1:8000/docs

## Open Android project
Open the `android` folder in Android Studio, allow Gradle sync, then run the app on an Android device. This environment did not have the Android SDK/Gradle build tool installed, so a compiled APK is not included.

## Next implementation steps
- Add secure Google OAuth flow and store refresh tokens server-side.
- Implement script generation and TTS using chosen providers.
- Implement video rendering and thumbnail generation.
- Add YouTube upload + scheduling with retry handling and quota monitoring.
- Add monitoring, logs, and failure alerts.
