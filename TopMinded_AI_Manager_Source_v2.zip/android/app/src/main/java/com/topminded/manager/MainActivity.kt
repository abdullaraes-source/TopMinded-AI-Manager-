package com.topminded.manager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TopMindedApp() }
    }
}

@Composable
fun TopMindedApp() {
    var shortsPerDay by remember { mutableStateOf(2f) }
    var longPerWeek by remember { mutableStateOf(2f) }
    var serverUrl by remember { mutableStateOf("https://your-server.example") }
    var autoPublish by remember { mutableStateOf(false) }

    MaterialTheme {
        Scaffold { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Text("TopMinded AI Manager", style = MaterialTheme.typography.headlineMedium)
                    Text("YouTube kanal boshqaruv paneli", style = MaterialTheme.typography.bodyMedium)
                }
                item {
                    ElevatedCard {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Reja", style = MaterialTheme.typography.titleLarge)
                            Text("Shorts: ${shortsPerDay.toInt()} ta / kun")
                            Slider(value = shortsPerDay, onValueChange = { shortsPerDay = it }, valueRange = 0f..4f, steps = 3)
                            Text("Uzun video: ${longPerWeek.toInt()} ta / hafta")
                            Slider(value = longPerWeek, onValueChange = { longPerWeek = it }, valueRange = 0f..5f, steps = 4)
                        }
                    }
                }
                item {
                    ElevatedCard {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Avtomatik joylash", style = MaterialTheme.typography.titleLarge)
                            Text("Sinov tugamaguncha o‘chirib qo‘yish tavsiya etiladi.")
                            Switch(checked = autoPublish, onCheckedChange = { autoPublish = it })
                            Text(if (autoPublish) "Yoqilgan (backend ulanishi talab qilinadi)" else "O‘chiq")
                        }
                    }
                }
                item {
                    OutlinedTextField(
                        value = serverUrl,
                        onValueChange = { serverUrl = it },
                        label = { Text("Server URL") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Button(onClick = { /* TODO: persist settings and call backend */ }, modifier = Modifier.fillMaxWidth()) {
                        Text("Sozlamalarni saqlash (keyingi bosqich)")
                    }
                }
                item {
                    Text("Holat: Demo rejim", color = MaterialTheme.colorScheme.primary)
                    Text("AI, ovoz, montaj va YouTube OAuth integratsiyalari hali ulanmagan.")
                }
            }
        }
    }
}
