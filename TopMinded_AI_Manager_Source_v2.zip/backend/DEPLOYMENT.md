# Backend deployment checklist

- Deploy this API to a trusted HTTPS host with persistent storage.
- Set `TIMEZONE=Asia/Tashkent`.
- Keep all provider credentials in server-side environment variables or a secrets manager.
- Add Google OAuth consent and YouTube Data API v3 credentials.
- Implement token refresh, upload retries, quota tracking, and audit logs.
- Do not expose OAuth refresh tokens or API keys to the Android client.
- Keep `AUTO_PUBLISH=false` until test uploads and scheduled publishing are verified.
