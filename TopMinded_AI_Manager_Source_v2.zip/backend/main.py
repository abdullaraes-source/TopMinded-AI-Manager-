from datetime import datetime
from zoneinfo import ZoneInfo
import os
from fastapi import FastAPI
from pydantic import BaseModel, Field

app = FastAPI(title="TopMinded AI Manager API", version="0.1.0")
TZ = ZoneInfo(os.getenv("TIMEZONE", "Asia/Tashkent"))

class Schedule(BaseModel):
    shorts_per_day: int = Field(default=2, ge=0, le=6)
    long_videos_per_week: int = Field(default=2, ge=0, le=7)
    auto_publish: bool = False

schedule = Schedule(
    shorts_per_day=int(os.getenv("SHORTS_PER_DAY", "2")),
    long_videos_per_week=int(os.getenv("LONG_VIDEOS_PER_WEEK", "2")),
    auto_publish=os.getenv("AUTO_PUBLISH", "false").lower() == "true",
)

@app.get("/health")
def health():
    return {"ok": True, "service": "topminded-ai-manager", "time": datetime.now(TZ).isoformat()}

@app.get("/status")
def status():
    return {
        "mode": "configured" if os.getenv("AI_API_KEY") and os.getenv("TTS_API_KEY") else "demo",
        "schedule": schedule.model_dump(),
        "integrations": {
            "script_generation": bool(os.getenv("AI_API_KEY")),
            "tts": bool(os.getenv("TTS_API_KEY")),
            "youtube_oauth": os.path.exists(os.getenv("YOUTUBE_TOKEN_FILE", "token.json")),
            "video_renderer": False,
        },
        "note": "Autonomous publishing is not active until all integrations are implemented and tested."
    }

@app.get("/schedule")
def get_schedule():
    return schedule

@app.put("/schedule")
def update_schedule(new_schedule: Schedule):
    global schedule
    schedule = new_schedule
    return {"saved": True, "schedule": schedule}

@app.post("/jobs/preview")
def preview_job():
    # Safe preview endpoint. Production worker should generate script, narration,
    # rendered video and thumbnail, then queue for YouTube upload.
    return {
        "accepted": True,
        "stage": "preview_only",
        "message": "Production generation pipeline and YouTube OAuth upload still need configuration."
    }
